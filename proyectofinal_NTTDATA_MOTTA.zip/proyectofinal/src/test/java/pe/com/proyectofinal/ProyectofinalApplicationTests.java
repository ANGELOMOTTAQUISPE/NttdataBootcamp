package pe.com.proyectofinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectofinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
