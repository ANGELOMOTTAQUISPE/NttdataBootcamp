package pe.com.proyectofinal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import pe.com.proyectofinal.controller.ClientController;
import pe.com.proyectofinal.model.Client;
import pe.com.proyectofinal.service.IClientService;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class ControllerClientTest {
    @InjectMocks
    ClientController clientcontroller;
    @Mock
    private IClientService service;

    private Client client;

    @Before
    public void setup() throws Exception {
    client = Client.builder().dni("05214478").name("Pepe").lastName("Casas").afp("PRIMA").email("pepe@gmail.com").phone("96325478").build();

    }
    @Test
    public void testOk() throws Exception {
        /*ListarSerieUnificadaResponse responseUsu = ListarSerieUnificadaResponse.builder()
                .listarSerieUnificadaResponse(dataResponse).build();

        Mockito.when(iMetodosRest.listar(Mockito.any(),Mockito.any())).thenReturn(responseUsu);

        ListarSerieUnificadaResponse response = controlador.usuariosResponse(idTransaccion, request);
        assertNotNull(response);
        assertEquals(responseUsu.getListarSerieUnificadaResponse(), response.getListarSerieUnificadaResponse());*/
    }

    @Test
    public void testOkError() throws Exception {

        Mockito.when(clientcontroller.list()).thenThrow(Exception.class);

        ResponseEntity<List<Client>> response = clientcontroller.list();
        assertNotNull(response);
    }
}
