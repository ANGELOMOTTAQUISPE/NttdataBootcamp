package pe.com.proyectofinal.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.com.proyectofinal.model.Request;
import pe.com.proyectofinal.repo.IRequestRepo;
import pe.com.proyectofinal.service.IRequestService;

import java.util.List;
import java.util.Optional;
@Service
public class RequestServiceImpl implements IRequestService {
    @Autowired
    private IRequestRepo repo;

    @Override
    public Request register(Request obj) {
        return repo.save(obj);
    }

    @Override
    public Request modify(Request obj) {
        return repo.save(obj);
    }

    @Override
    public List<Request> list() {
        return repo.findAll();
    }

    @Override
    public Request listofId(Integer id) {
        Optional<Request> op = repo.findById(id);
        return op.isPresent() ? op.get() : new Request();
    }

    @Override
    public boolean delete(Integer id) {
        repo.deleteById(id);
        return true;
    }
}
