package pe.com.proyectofinal.service;

import pe.com.proyectofinal.model.Client;

public interface IClientService extends ICRUD<Client, Integer>{
}
