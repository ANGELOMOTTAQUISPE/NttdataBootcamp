package pe.com.proyectofinal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.com.proyectofinal.model.Request;

public interface IRequestRepo extends JpaRepository<Request, Integer> {
}
