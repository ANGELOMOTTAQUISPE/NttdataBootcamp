package pe.com.proyectofinal.service;

import pe.com.proyectofinal.model.Client_AFP;

public interface IClienteAFPService extends ICRUD<Client_AFP, Integer>{
}
