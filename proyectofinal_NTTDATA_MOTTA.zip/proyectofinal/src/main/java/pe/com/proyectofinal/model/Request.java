package pe.com.proyectofinal.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Información de la solicitud")
@Entity(name = "request")
@Table(name = "request")
public class Request implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idRequest;

    @ManyToOne
    @JoinColumn(name = "dni", nullable = false, foreignKey = @ForeignKey(name = "fk_dni_Request"), referencedColumnName="dni")
    private Client dni;

    @Column(name = "withdrawalAmount ", nullable = false, length = 70)
    private Integer withdrawalAmount ;

    @Column(name = "dateRequest  ", nullable = false)
    private LocalDateTime dateRequest;
}
