package pe.com.proyectofinal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.com.proyectofinal.exception.ModelNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.com.proyectofinal.service.IClientService;
import pe.com.proyectofinal.model.Client;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/client")
public class ClientController {
    private static final Logger logger = LoggerFactory.getLogger(ClientController.class);
    @Autowired
    private IClientService service;
    @GetMapping
    public ResponseEntity<List<Client>> list(){
        logger.info("Inicio metodo list() de clientcontroller");
        List<Client> lista = new ArrayList<Client>();
        try {
            lista = service.list();

        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo list() de clientcontroller");
        }
        return new ResponseEntity<List<Client>>(lista, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Client> register(@Valid @RequestBody Client client){
        logger.info("Inicio metodo register() de clientcontroller");
        Client p = new Client();
        try {
            logger.info("IdCLIENTE: "+client.getDni());
            p = service.register(client);
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo register() de clientcontroller");
        }

        return new ResponseEntity<Client>(p, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Client> listId(@PathVariable("id") Integer id){
        logger.info("Inicio metodo listId() de clientcontroller");
        Client p = new Client();
        try {
            p = service.listofId(id);
            if (p.getIdCliente() == null){
                throw new ModelNotFoundException("CLIENTE NO ENCONTRADO CON ID: " + id);
            }
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo listId() de clientcontroller");
        }
        return new ResponseEntity<Client>(p, HttpStatus.OK);

    }

    @PutMapping
    public ResponseEntity<Client> update(@Valid @RequestBody Client client){
        logger.info("Inicio metodo update() de clientcontroller");
        Client p = new Client();
        try {
            p = service.modify(client);
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo update() de clientcontroller");
        }
        return new ResponseEntity<Client>(p, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable("id") Integer id) {
        logger.info("Inicio metodo delete() de clientcontroller");
        Client p = new Client();
        try {
            p = service.listofId(id);
            service.delete(id);
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo delete() de clientcontroller");
        }
        return new ResponseEntity<Object>(HttpStatus.OK);
    }
}
