package pe.com.proyectofinal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.com.proyectofinal.model.Client_AFP;

public interface IClienteAFPRepo extends JpaRepository<Client_AFP, Integer> {
}
