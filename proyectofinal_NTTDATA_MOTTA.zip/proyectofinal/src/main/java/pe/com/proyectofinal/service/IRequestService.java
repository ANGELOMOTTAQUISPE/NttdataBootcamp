package pe.com.proyectofinal.service;

import pe.com.proyectofinal.model.Request;

public interface IRequestService extends ICRUD<Request, Integer>{
}
