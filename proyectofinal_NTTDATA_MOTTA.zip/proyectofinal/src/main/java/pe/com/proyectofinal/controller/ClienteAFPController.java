package pe.com.proyectofinal.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.com.proyectofinal.exception.ModelNotFoundException;
import pe.com.proyectofinal.model.Client;
import pe.com.proyectofinal.model.Client_AFP;
import pe.com.proyectofinal.model.Request;
import pe.com.proyectofinal.service.IClienteAFPService;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/clientafp")
public class ClienteAFPController {
    private static final Logger logger = LoggerFactory.getLogger(ClienteAFPController.class);
    @Autowired
    private IClienteAFPService service;
    @GetMapping
    public ResponseEntity<List<Client_AFP>> list(){
        logger.info("Inicio metodo list() de clienteafpcontroller");
        List<Client_AFP> lista = new ArrayList<Client_AFP>();
        try {
            lista = service.list();

        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo list() de clienteafpcontroller");
        }
        return new ResponseEntity<List<Client_AFP>>(lista, HttpStatus.OK);
    }
    @PostMapping
    public ResponseEntity<Client_AFP> register(@Valid @RequestBody Client_AFP clienteafp){
        logger.info("Inicio metodo register() de clienteafpcontroller");

        Client_AFP p = new Client_AFP();
        try {
            p = service.register(clienteafp);

        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo register() de clienteafpcontroller");
        }

        return new ResponseEntity<Client_AFP>(p, HttpStatus.CREATED);

    }
    @GetMapping("/{id}")
    public ResponseEntity<Client_AFP> listId(@PathVariable("id") Integer id){
        logger.info("Inicio metodo listId() de clienteafpcontroller");
        Client_AFP p = new Client_AFP();
        try {
            p = p = service.listofId(id);
            if (p.getIdRequest() == null){
                throw new ModelNotFoundException("DATOS AFP NO ENCONTRADO CON ID: " + id);
            }
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo listId() de clienteafpcontroller");
        }
        return new ResponseEntity<Client_AFP>(p, HttpStatus.OK);

    }
    @PutMapping
    public ResponseEntity<Client_AFP> update(@Valid @RequestBody Client_AFP clientafp){
        logger.info("Inicio metodo update() de clienteafpcontroller");
        Client_AFP p = new Client_AFP();
        try {
            p = service.modify(clientafp);
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo update() de clienteafpcontroller");
        }
        return new ResponseEntity<Client_AFP>(p, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> delete(@PathVariable("id") Integer id) {
        logger.info("Inicio metodo delete() de clientcontroller");
        Client_AFP p = new Client_AFP();
        try {
            p = service.listofId(id);
            service.delete(id);
        } catch (Exception e) {
            logger.info("Ocurrio un error " + e.getMessage());

        }finally {
            logger.info( "Fin metodo delete() de clientcontroller");
        }
        return new ResponseEntity<Object>(HttpStatus.OK);
    }
}
