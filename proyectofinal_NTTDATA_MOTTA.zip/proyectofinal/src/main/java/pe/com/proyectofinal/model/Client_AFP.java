package pe.com.proyectofinal.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Información de la Asociacion AFP")
@Entity
@Table(name = "cliente_afp")
public class Client_AFP implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idRequest;

    @ManyToOne
    @JoinColumn(name = "dni", nullable = false, foreignKey = @ForeignKey(name = "fk_dni_Cliente_AFP"), referencedColumnName="dni")
    private Client dni;

    @Column(name = "amountAvailable", nullable = false, length = 70)
    private Integer amountAvailable ;

    @Column(name = "accountNumber", nullable = false, length = 70)
    private String accountNumber;
}
