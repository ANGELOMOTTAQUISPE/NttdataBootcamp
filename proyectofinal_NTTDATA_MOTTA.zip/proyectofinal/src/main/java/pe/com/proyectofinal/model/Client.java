package pe.com.proyectofinal.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.NaturalId;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Información del Cliente")
@Entity(name = "Client")
@Table(name = "client")
public class Client implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idCliente;

    @Schema(description = "name debe tener minimo 3 caracteres")
    @Size(min = 3, message = "Nombres debe tener minimo 3 caracteres")
    @Column(name = "name", nullable = false, length = 70)
    private String name;

    @Size(min = 3, message = "lastName debe tener minimo 3 caracteres")
    @Column(name = "lastName", nullable = false, length = 70)
    private String lastName;
    @NaturalId
    @Size(min = 8, max = 8, message = "DNI debe tener 8 caracteres")
    @Column(name = "dni", nullable = false, length = 8,unique = true)
    private String dni;

    @Size(min = 9, max = 9, message = "phone debe tener 9 caracteres")
    @Column(name = "phone", nullable = true, length = 9)
    private String phone;

    @Email
    @Column(name = "email", nullable = true, length = 55)
    private String email;

    @Size(min = 3, message = "AFP debe tener mínimo 3 caracteres")
    @Column(name = "afp", nullable = true, length = 55)
    private String afp;
}
