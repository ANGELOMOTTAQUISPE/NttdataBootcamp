package pe.com.proyectofinal.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.com.proyectofinal.model.Client_AFP;
import pe.com.proyectofinal.repo.IClienteAFPRepo;
import pe.com.proyectofinal.service.IClienteAFPService;

import java.util.List;
import java.util.Optional;
@Service
public class ClienteAFPServiceImpl implements IClienteAFPService {
    @Autowired
    private IClienteAFPRepo repo;

    @Override
    public Client_AFP register(Client_AFP obj) {
        return repo.save(obj);
    }

    @Override
    public Client_AFP modify(Client_AFP obj) {
        return repo.save(obj);
    }

    @Override
    public List<Client_AFP> list() {
        return repo.findAll();
    }

    @Override
    public Client_AFP listofId(Integer id) {
        Optional<Client_AFP> op = repo.findById(id);
        return op.isPresent() ? op.get() : new Client_AFP();
    }

    @Override
    public boolean delete(Integer id) {
        repo.deleteById(id);
        return true;
    }

}
