package pe.com.proyectofinal.service.impl;

import org.springframework.stereotype.Service;
import pe.com.proyectofinal.model.Client;
import pe.com.proyectofinal.repo.IClientRepo;
import pe.com.proyectofinal.service.IClientService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;
@Service
public class ClientServiceImpl implements IClientService{
    @Autowired
    private IClientRepo repo;

    @Override
    public Client register(Client obj) {
        return repo.save(obj);
    }

    @Override
    public Client modify(Client obj) {
        return repo.save(obj);
    }

    @Override
    public List<Client> list() {
        return repo.findAll();
    }

    @Override
    public Client listofId(Integer id) {
        Optional<Client> op = repo.findById(id);
        return op.isPresent() ? op.get() : new Client();
    }

    @Override
    public boolean delete(Integer id) {
        repo.deleteById(id);
        return true;
    }
}
