package pe.com.proyectofinal.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.com.proyectofinal.model.Client;

public interface IClientRepo extends JpaRepository<Client, Integer> {
}
