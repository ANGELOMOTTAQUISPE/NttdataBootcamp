package pe.com.proyectofinal.service;

import java.util.List;

public interface ICRUD <T, V>{
    T register(T obj);
    T modify(T obj);
    List<T> list();
    T listofId(V id);
    boolean delete(V id);
}
